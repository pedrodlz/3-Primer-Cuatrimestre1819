// #############################################################################
//
// Informática Gráfica (Grado Informática)
//
// Archivo: jerarquico.h
// -- implementación del objeto jerárquico de la práctica 3
//
// #############################################################################


#include "jerarquico.h"

ObjJerarquico::ObjJerarquico()
{
   // crear la jerarquía de objetos, sub-objetos, sub-sub-objetos, etc...  (práctica 3)
   // (no se usa ninguna llamada a OpenGL, solo creación de la estructura)

}

// -----------------------------------------------------------------------------
// visualización del objeto Jerárquico con OpenGL,
// mediante llamadas a los métodos 'draw' de los sub-objetos

void ObjJerarquico::draw()
{

}

// -----------------------------------------------------------------------------
